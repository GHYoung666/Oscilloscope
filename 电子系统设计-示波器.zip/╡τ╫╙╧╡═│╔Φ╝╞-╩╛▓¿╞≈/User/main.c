/*********************************************************************************
 * �����ʣ�ԼΪ16000kps
 * ˫ͨ��ʵ�֣�307��������ADC������ײ���������ַ�ʽ�ɵ�����ʽһ��ADC1��ADC2ʹ�ý�����ٲ���ͬһ�����Σ���ʽ����ADC1�������Σ�ADC2������ƽ�ź�ת��Ϊ�Ŵ���
 * ���ڷ�ֵ�������л�����ʾ��OLED��
 * �жϣ������������ȼ��ɵ͵��߷ֱ�Ϊ��DMA���βɼ��жϡ����벶���жϡ�EXTI�����ⲿ�����ж�
 * DMA���ݿ��ٴ���
 * ���Զ˲��λָ���ʹ�ô��ڵ�������
 * �˲���MATLAB�����ⲻ��
 ********************************************************************************/

#include "debug.h"

#define led1 GPIO_ReadOutputDataBit(GPIOD, GPIO_Pin_7)

volatile uint16_t sine_sampling;
float PrintVoltage,CompareVoltage,ADCMax,ADCMin = 5;
uint8_t samplingflag,ChoiceFlag = 0;
uint16_t risenum;
uint16_t fallnum;
float wavetime;
uint8_t keypushed;
u16 Amp ;
float print_inc = 1.0;
s16 Calibrattion_Val = 0;

/**************************************************************************************
 * ����TIM2��ʱ������PWM������ADC����
 ******************************************************************************************/
void TIM1_Init(){
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE );
    TIM_TimeBaseStructInit(&TIM_TimeBaseInitStructure);
    TIM_TimeBaseInitStructure.TIM_Period = 4000-1;     // 0.4ms Update
    TIM_TimeBaseInitStructure.TIM_Prescaler = 72-1;    // 1MHz
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    //TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 64-1;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);

    //TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;  // ����ֵ���ڱȽ�ֵ�������Ч��ƽ��
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 1000; //(u16)((TIM_TimeBaseInitStructure.TIM_Period+1)/2-1);
    TIM_OC2Init(TIM2, &TIM_OCInitStructure);

    TIM_ARRPreloadConfig(TIM2, ENABLE);
    //TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
    //TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);  // ����Update�ж�
    TIM_Cmd(TIM2, ENABLE);
    TIM_CtrlPWMOutputs(TIM2, ENABLE);
}

/**************************************************************************************
 * DMAת��ADC���������ݣ��������ж����
 ******************************************************************************************/
void DMA_INIT(){

    DMA_InitTypeDef DMA_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
 //   NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);

    DMA_DeInit(DMA1_Channel1);
    //DMA_StructInit(&DMA_InitStructure);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)(&(ADC1->RDATAR));
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&sine_sampling;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
    DMA_InitStructure.DMA_BufferSize = 1;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);

    DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE);
    DMA_Cmd(DMA1_Channel1,ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

}

/**************************************************************************************
 * DMA�жϷ������ע��Ҫ���жϳ�������
 ******************************************************************************************/
void  DMA1_Channel1_IRQHandler(void)    __attribute__((interrupt("WCH-Interrupt-fast")));
void  DMA1_Channel1_IRQHandler(void)
{
    DMA_ClearFlag(DMA1_FLAG_TC1);
    PrintVoltage = (float)sine_sampling*(3.3/4095)*print_inc;
  //  printf("%f\r\n",PrintVoltage);
    if(ChoiceFlag % 3 == 0)
    {
        printf("%f\r\n",PrintVoltage);
        //UsartPrintf(UART6,"%f\r\n",PrintVoltage);
    }

    if(ChoiceFlag % 3 == 1)
    {
        if(PrintVoltage > CompareVoltage && PrintVoltage > ADCMax)
        {
            ADCMax = PrintVoltage;
        }
        printf("Max:%fV\t",ADCMax);
        //UsartPrintf(UART6,"Max:%fV\t",ADCMax);
        if(PrintVoltage < CompareVoltage && PrintVoltage < ADCMin)
        {
            ADCMin = PrintVoltage;
        }
        printf("Min:%fV\r\n",ADCMin);
        //UsartPrintf(UART6,"Min:%fV\t",ADCMin);
        CompareVoltage = PrintVoltage;
    }
}

/**************************************************************************************
 * ADC1��ͨ������
 ******************************************************************************************/
#if 1       //��ͨ��
void ADC1_TIM1_DMA1_Config(void)
{
    /* GPIO Init */
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    TIM1_Init();
    DMA_INIT();

    /* ADC Init */
    ADC_InitTypeDef ADC_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

    //ADC_DeInit(ADC1);

    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T2_CC2;  // TIM1��OC1ͨ�������ش���
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &ADC_InitStructure);

    RCC_ADCCLKConfig(RCC_PCLK2_Div4);//4��Ƶ

    //ADC1
    ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 1, ADC_SampleTime_7Cycles5 );

    ADC_DMACmd(ADC1, ENABLE);   // ����DMA����
    ADC_Cmd(ADC1, ENABLE);      // ʹ��ADC

    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));

    ADC_ExternalTrigConvCmd(ADC1, ENABLE);
}
#endif

/**************************************************************************************
 * ADC12˫ͨ��������ٲ���
 ******************************************************************************************/
#if 0       //˫ͨ��
void ADC1_TIM1_DMA1_Config()
{
    GPIO_InitTypeDef GPIO_InitStructure={0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    RCC_ADCCLKConfig(RCC_PCLK2_Div4);//4��Ƶ

    TIM1_Init();
    DMA_INIT();

    /* GPIO Init */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* ADC Init */
    ADC_InitTypeDef ADC_InitStructure={0};
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, ENABLE);

    ADC_DeInit(ADC1);
    ADC_DeInit(ADC2);

    ADC_InitStructure.ADC_Mode = ADC_Mode_FastInterl;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T2_CC2;  // TIM1��OC1ͨ�������ش���
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 2;
    ADC_InitStructure.ADC_OutputBuffer = ADC_OutputBuffer_Disable;
    ADC_InitStructure.ADC_Pga=ADC_Pga_1;

    ADC_Init(ADC1, &ADC_InitStructure);
    ADC_Init(ADC2, &ADC_InitStructure);
    //ͨ��һ
    ADC_ExternalTrigConvCmd(ADC1, ENABLE);
    ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 1, ADC_SampleTime_7Cycles5 );

    ADC_DMACmd(ADC1, ENABLE);   // ����DMA����
    ADC_Cmd(ADC1, ENABLE);      // ʹ��ADC

    ADC_BufferCmd(ADC1, DISABLE);   //disable buffer
    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));
    ADC_DMACmd(ADC1, ENABLE);

    //ͨ����
    ADC_ExternalTrigConvCmd(ADC2, ENABLE);
    ADC_RegularChannelConfig(ADC2, ADC_Channel_2, 2, ADC_SampleTime_7Cycles5 );

    ADC_DMACmd(ADC2, ENABLE);   // ����DMA����
    ADC_Cmd(ADC2, ENABLE);      // ʹ��ADC

    ADC_BufferCmd(ADC2, DISABLE);   //disable buffer
    ADC_ResetCalibration(ADC2);
    while(ADC_GetResetCalibrationStatus(ADC2));
    ADC_StartCalibration(ADC2);
    while(ADC_GetCalibrationStatus(ADC2));
    ADC_DMACmd(ADC2, ENABLE);
    /* TIM Init */  /* TIM1.OC1 */

}
#endif


/**************************************************************************************
 * ���벶�񣬿�������ͨ�����ֱ𲶻������غ��½��أ������ƽ����ʱ�䣨����չ����ռ�ձȣ�
 ******************************************************************************************/
void Input_Capture_Init( u16 arr, u16 psc )
{
    GPIO_InitTypeDef GPIO_InitStructure={0};
    TIM_ICInitTypeDef TIM_ICInitStructure={0};
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure={0};
    NVIC_InitTypeDef NVIC_InitStructure={0};

    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA | RCC_APB2Periph_TIM1, ENABLE );

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init( GPIOA, &GPIO_InitStructure);
    GPIO_ResetBits( GPIOA, GPIO_Pin_8 );

    TIM_TimeBaseInitStructure.TIM_Period = arr;
    TIM_TimeBaseInitStructure.TIM_Prescaler = psc;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter =  0x00;
    TIM_TimeBaseInit( TIM1, &TIM_TimeBaseInitStructure);

    TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;
    TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;
    TIM_ICInitStructure.TIM_ICFilter = 0x00;
    TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
    TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;

    TIM_PWMIConfig( TIM1, &TIM_ICInitStructure );

    NVIC_InitStructure.NVIC_IRQChannel = TIM1_CC_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    TIM_ITConfig( TIM1, TIM_IT_CC1 | TIM_IT_CC2, ENABLE );

    TIM_SelectInputTrigger( TIM1, TIM_TS_TI1FP1 );
    TIM_SelectSlaveMode( TIM1, TIM_SlaveMode_Reset );
    TIM_SelectMasterSlaveMode( TIM1, TIM_MasterSlaveMode_Enable );
    TIM_Cmd( TIM1, ENABLE );
}

/**************************************************************************************
 * ���벶���жϣ��������
 ******************************************************************************************/
void  TIM1_CC_IRQHandler(void)    __attribute__((interrupt("WCH-Interrupt-fast")));
void TIM1_CC_IRQHandler(void)
{
        if( TIM_GetITStatus( TIM1, TIM_IT_CC1 ) != RESET )
        {
            //printf( "CH1_Val:%d\r\n", TIM_GetCapture1( TIM1 ) );
            risenum = TIM_GetCapture1( TIM1 );
            TIM_SetCounter( TIM1, 0 );
        }

        if( TIM_GetITStatus( TIM1, TIM_IT_CC2 ) != RESET )
        {
            //printf( "CH2_Val:%d\r\n", TIM_GetCapture2( TIM1 ) );
            fallnum = TIM_GetCapture2( TIM1 );
        }

        wavetime = (float)(risenum - fallnum)*2/1000;
        printf("%f ms\r\n",wavetime);
        //UsartPrintf(UART6,"%f ms\r\n",wavetime);
        Delay_Us(100);
        TIM_ClearITPendingBit( TIM1, TIM_IT_CC1 | TIM_IT_CC2 );

}



/**************************************************************************************
 *�����û�����
 ******************************************************************************************/
void key_init(void)//����Ϊ0���ɿ�Ϊ1
{
    GPIO_InitTypeDef GPIO_InitStructure={0};
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA , ENABLE );
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init( GPIOA, &GPIO_InitStructure );
}

/**************************************************************************************
 * �����û������жϳ����ʼ����EXTIline4
 ******************************************************************************************/
void EXTI4_INT_INIT(void)
{
    EXTI_InitTypeDef EXTI_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOA, ENABLE);

    key_init();

    /* GPIOA ----> EXTI_Line0 */
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource4);
    EXTI_InitStructure.EXTI_Line = EXTI_Line4;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}
/**************************************************************************************
 * �����û������жϷ������EXTIline4
 ******************************************************************************************/
void EXTI4_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void EXTI4_IRQHandler(void)
{

    Delay_Ms(200);    //����
    ChoiceFlag += 1;
    printf("%f\r\n",ChoiceFlag);
    if(ChoiceFlag % 3 == 0 || ChoiceFlag % 3 == 1)
    {
        TIM_CtrlPWMOutputs(TIM2, ENABLE);
        TIM_ITConfig( TIM1, TIM_IT_CC1 | TIM_IT_CC2, DISABLE );
        TIM_Cmd( TIM1, DISABLE );
    }
    if(ChoiceFlag % 3 == 2)
    {
        TIM_CtrlPWMOutputs(TIM2, DISABLE);
        TIM_ITConfig( TIM1, TIM_IT_CC1 | TIM_IT_CC2, ENABLE );
        TIM_Cmd( TIM1, ENABLE );
    }


    EXTI_ClearITPendingBit(EXTI_Line4);  //���EXTI0��·����λ
}
/**************************************************************************************
 * ����LED��ʼ������PD7
 ******************************************************************************************/
void LED_Init(void)
{

 GPIO_InitTypeDef  GPIO_InitStructure={0};

 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);  //ʹ��PB,PE�˿�ʱ��

 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;              //LED1-->PE.5 �˿�����, �������
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;       //�������
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;       //IO���ٶ�Ϊ50MHz
 GPIO_Init(GPIOD, &GPIO_InitStructure);                  //������� ��IO���ٶ�Ϊ50MHz
 GPIO_SetBits(GPIOD,GPIO_Pin_7);                        //PC13 �����
}
/**************************************************************************************
 * ����û�������ʼ������
 ******************************************************************************************/
void key2_init(void)//����Ϊ0���ɿ�Ϊ1
{
    GPIO_InitTypeDef GPIO_InitStructure={0};
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA , ENABLE );
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init( GPIOA, &GPIO_InitStructure );
}

uint8_t KEY_Scan(void)
{
    return GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0);// �ް�������
}
/**************************************************************************************
 *ͨ������������ȡ��ֵ
 ******************************************************************************************/
void  Adc_Init(void)
{
    ADC_InitTypeDef ADC_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE );   //ʹ��ADC1ͨ��ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, ENABLE);


    RCC_ADCCLKConfig(RCC_PCLK2_Div6);   //����ADC��Ƶ����6 72M/6=12,ADC���ʱ�䲻�ܳ���14M

    //PA1 ��Ϊģ��ͨ����������
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;       //ģ����������
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    ADC_DeInit(ADC2);  //��λADC1,������ ADC1 ��ȫ���Ĵ�������Ϊȱʡֵ

    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;  //ADC����ģʽ:ADC1��ADC2�����ڶ���ģʽ
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;   //ģ��ת�������ڵ�ͨ��ģʽ
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE; //ģ��ת�������ڵ���ת��ģʽ
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None; //ת���������������ⲿ��������
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;  //ADC�����Ҷ���
    ADC_InitStructure.ADC_NbrOfChannel = 1; //˳����й���ת����ADCͨ������Ŀ
    ADC_Init(ADC2, &ADC_InitStructure); //����ADC_InitStruct��ָ���Ĳ�����ʼ������ADCx�ļĴ���


    ADC_Cmd(ADC2, ENABLE);  //ʹ��ָ����ADC1
    ADC_BufferCmd(ADC2, DISABLE);

    //ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 1, ADC_SampleTime_28Cycles5 );

    ADC_ResetCalibration(ADC2); //ʹ�ܸ�λУ׼
    while(ADC_GetResetCalibrationStatus(ADC2)); //�ȴ���λУ׼����
    ADC_StartCalibration(ADC2);  //����ADУ׼
    while(ADC_GetCalibrationStatus(ADC2));   //�ȴ�У׼����
    Calibrattion_Val = Get_CalibrationValue(ADC2);
    ADC_BufferCmd(ADC2, ENABLE);

//  ADC_SoftwareStartConvCmd(ADC1, ENABLE);     //ʹ��ָ����ADC1������ת����������
}
/**************************************************************************************
 * ��ȡADC��ֵ
 ******************************************************************************************/
u16 Get_Adc(u8 ch)
{
    //����ָ��ADC�Ĺ�����ͨ����һ�����У�����ʱ��
    ADC_RegularChannelConfig(ADC2, ch, 1, ADC_SampleTime_239Cycles5 );  //ADC1,ADCͨ��,����ʱ��Ϊ239.5����

    ADC_SoftwareStartConvCmd(ADC2, ENABLE);     //ʹ��ָ����ADC1������ת����������

    while(!ADC_GetFlagStatus(ADC2, ADC_FLAG_EOC ));//�ȴ�ת������

    return ADC_GetConversionValue(ADC2);    //�������һ��ADC1�������ת�����
}
u16 Get_Adc_Average(u8 ch,u8 times)
{
    u32 temp_val=0;
    u8 t;
    for(t=0;t<times;t++)
    {
        temp_val+=Get_Adc(ch);
        Delay_Ms(5);
    }
    return temp_val/times;
}
/**************************************************************************************
 * ��簴���жϳ�ʼ��&�������
 ******************************************************************************************/
void EXTI0_INT_INIT(void)
{
    EXTI_InitTypeDef EXTI_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOA, ENABLE);

    key_init();

    /* GPIOA ----> EXTI_Line0 */
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);
    EXTI_InitStructure.EXTI_Line = EXTI_Line0;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void EXTI0_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void EXTI0_IRQHandler(void)
{
    Delay_Ms(80);    //����
    keypushed = KEY_Scan();
    if(keypushed == 0)
    {
        if(led1)GPIO_ResetBits(GPIOD,GPIO_Pin_7);
        else {
            GPIO_SetBits(GPIOD,GPIO_Pin_7);
        }
        Amp = Get_Adc(ADC_Channel_3);
        print_inc = (float)Amp*(3.3/4095);
        //printf("Amp:%d\r\n",Amp);
    }

    EXTI_ClearITPendingBit(EXTI_Line0);  //���EXTI0��·����λ
}

void MyUsart_Init(unsigned int baud)
{

    GPIO_InitTypeDef gpioInitStruct;
    USART_InitTypeDef usartInitStruct;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART6, ENABLE);

    //PA9   TXD
    gpioInitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    gpioInitStruct.GPIO_Pin = GPIO_Pin_0;
    gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &gpioInitStruct);

    //PA10  RXD
    gpioInitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    gpioInitStruct.GPIO_Pin = GPIO_Pin_1;
    gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &gpioInitStruct);

    usartInitStruct.USART_BaudRate = baud;
    usartInitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;     //��Ӳ������
    usartInitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;                     //���պͷ���
    usartInitStruct.USART_Parity = USART_Parity_No;                                 //��У��
    usartInitStruct.USART_StopBits = USART_StopBits_1;                              //1λֹͣλ
    usartInitStruct.USART_WordLength = USART_WordLength_8b;                         //8λ����λ
    USART_Init(UART6, &usartInitStruct);

    USART_Cmd(UART6, ENABLE);                                                      //ʹ�ܴ���

}

void UsartPrintf(USART_TypeDef *USARTx, char *fmt,...)
{

    unsigned char UsartPrintfBuf[296];
    va_list ap;
    unsigned char *pStr = UsartPrintfBuf;

    va_start(ap, fmt);
    vsnprintf((char *)UsartPrintfBuf, sizeof(UsartPrintfBuf), fmt, ap);                         //��ʽ��
    va_end(ap);

    while(*pStr != 0)
    {
        USART_SendData(USARTx, *pStr++);
        while(USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
    }
}


int main(void)
{
//    u32 temp=0;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);//���� NVIC �жϷ��� 2:2 λ��ռ���ȼ��� 2 λ��Ӧ���ȼ�
//    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
    Delay_Init(); //��ʱ������ʼ��
    USART_Printf_Init(115200); //���ڳ�ʼ��Ϊ 115200
    key2_init();
    EXTI0_INT_INIT();
    LED_Init();
    Adc_Init();
    EXTI4_INT_INIT();
    Input_Capture_Init( 0xFFFF, 72-1 ); //�� 1Mhz ��Ƶ�ʼ���
    ADC1_TIM1_DMA1_Config();
  while(1)
   {
//    Delay_Ms(10);
//    TIM_SetCompare1(TIM1,TIM_GetCapture1(TIM1)+1);
//    if(TIM_GetCapture1(TIM1)==300)TIM_SetCompare1(TIM1,0);
//    if(TIM1CH1_CAPTURE_STA&0X80)//�ɹ�������һ�θߵ�ƽ
//     {
//      temp=TIM1CH1_CAPTURE_STA&0X3F;
//      temp*=65536; //���ʱ���ܺ�
//      temp+=TIM1CH1_CAPTURE_VAL; //�õ��ܵĸߵ�ƽʱ��
//      //printf("HIGH:%d us\r\n",temp); //��ӡ�ܵĸߵ�ƽʱ��
//      TIM1CH1_CAPTURE_STA=0; //������һ�β���
//     }
   }
}

